---
fontFamily: "Roboto_Flex"

sidebar: "index"

numberOfPostsPerPage: 1

hiddenContentMessage: "This page is archived and may contain out of date information"
hiddenContentIsHidden: false
hiddenContentIsHiddenMessageHeading: "This content is unavailable"
hiddenContentIsHiddenMessageBodyText: "We're sorry, the page you're visiting is no longer available."

paginatedPostHeadlineSeparator: ""
paginatedCategoryHeadlineSeparator: ""
paginatedAuthorHeadlineSeparator: ""
paginatedPostSubtitlePrefix: " // Page "
paginatedCategorySubtitlePrefix: " // Page "
paginatedAuthorSubtitlePrefix: " // Page "

paginatedSubheadingIndexPrefix: "Displaying posts "
paginatedSubheadingTotalPrefix: " of "

orderPostsBy: "date"
orderPostsByReversed: false
orderPostsInCategoriesBy: "date"
orderPostsInCategoriesByReversed: false
orderPostsInAuthorsBy: "date"
orderPostsInAuthorsByReversed: false

orderPagesBy: "alphabetical"
orderPagesByReversed: false

orderCategoriesBy: "alphabetical"
orderCategoriesByReversed: false

orderAuthorsBy: "weight"
orderAuthorsByReversed: false

showPostCardCategory: true
showPostCardDate: true
showPostCardAuthor: false
showPostCardSnippet: true
showPostCardReadMoreButton: true


colorThemeNavDark: "slate-900"
colorThemeNavLight: "gray-100"
colorThemeHeroDark: "slate-900"
colorThemeHeroLight: "gray-100"
colorThemeBodyDark: "slate-800"
colorThemeBodyLight: "white"
colorThemeFooterDark: "slate-900"
colorThemeFooterLight: "gray-100"

colorNavBarBrandTextDark: "gray-100"
colorNavBarBrandTextLight: "gray-800"

colorNavMenuBackgroundDark: "slate-800"
colorNavMenuBackgroundLight: "white"
colorNavMenuBackgroundShadowDark: "gray-700"
colorNavMenuBackgroundShadowLight: "gray-700"
colorNavMenuTextDark: "gray-200"
colorNavMenuTextLight: "gray-800"

colorHeroHeadlineDark: "gray-200"
colorHeroHeadlineLight: "gray-800"
colorHeroSubtitleDark: "gray-500"
colorHeroSubtitleLight: "gray-500"
colorHeroSubheadingDark: "gray-200"
colorHeroSubheadingLight: "gray-800"
colorHeroSectionStringDark: "gray-200"
colorHeroSectionStringLight: "gray-800"
colorHeroSectionLinkDark: "gray-200"
colorHeroSectionLinkLight: "gray-800"
colorHeroDateDark: "gray-200"
colorHeroDateLight: "gray-800"
colorHeroSectionDateBorderDark: "green-700"
colorHeroSectionDateBorderLight: "stone-500"

colorContentBodyHeadingDark: ""
colorContentBodyHeadingLight: ""
colorContentBodyTextDark: ""
colorContentBodyTextLight: ""
colorContentLinkTextDark: ""
colorContentLinkTextLight: ""

colorPostCardHeadingDark: ""
colorPostCardHeadingLight: ""
colorPostCardTextDark: ""
colorPostCardTextLight: ""
colorPostCardReadMoreTextDark: ""
colorPostCardReadMoreTextLight: ""

colorAuthorCardHeadingDark: ""
colorAuthorCardHeadingLight: ""
colorAuthorCardTextDark: ""
colorAuthorCardTextLight: ""
colorAuthorCardLinkLabelDark: ""
colorAuthorCardLinkLabelLight: ""
colorAuthorCardLinkTextDark: ""
colorAuthorCardLinkTextLight: ""
colorAuthorCardLinkTextHoverDark: ""
colorAuthorCardLinkTextHoverLight: ""

colorSidebarRelatedPostDark: ""
colorSidebarRelatedPostLight: ""
colorSidebarRelatedPostHoverDark: ""
colorSidebarRelatedPostHoverLight: ""

colorSidebarPinnedPostDark: ""
colorSidebarPinnedPostLight: ""
colorSidebarHeadingDark: ""
colorSidebarHeadingLight: ""
colorSidebarTextDark: ""
colorSidebarTextLight: ""
colorSidebarLinkTextDark: ""
colorSidebarLinkTextLight: ""

colorTableOfContentsTextDark: ""
colorTableOfContentsTextLight: ""
colorTableOfContentsTextHoverDark: ""
colorTableOfContentsTextHoverLight: ""
colorTableOfContentsTextActiveDark: ""
colorTableOfContentsTextActiveLight: ""

colorFooterLinkTextDark: ""
colorFooterLinkTextLight: ""

---

Eggspress makes it easy to use Google Fonts via the fontFamily key above. We recommend using variable fonts, which you can find in this list https://fonts.google.com/variablefonts#font-families and preview at https://fonts.google.com/?vfonly=true

Note: when setting fonts, replace spaces in names with underscores ("Roboto Flex" becomes "Roboto_Flex," for example).

The "sidebar" key allows you to specify which sidebar to display on the main ("index") page. By default, it points to a sidebar in the my_sidebars folder named index.md. To change this sidebar, open the my_sidebars folder and edit index.md.

Keys prefixed with "showPostCard" allow you to toggle elements that appear in post cards on and off. The title of the post must appear, but all other elements can be switched on or off. If an item is on, it should be set to "true" (without quotation marks) and "false" or empty otherwise.

Keys prefixed with "color" allow you to define the color scheme of your Eggspress blog. Eggspress uses Tailwind, which includes an expansive palette of predefined colors to choose from here: https://tailwindcss.com/docs/customizing-colors.

All color keys are split between light and dark mode with "Light" and "Dark" suffixes.

To set a custom color, set the value of a color to its hexadecimal value in square brackets. For example, colorHeroHeadlineLight: "[#239e44]" sets the site title / content headline text to a green color defined by hexadecimal value #239e44.

The value "transparent" can also be used to set a color key.

To change your icons and logos, replace the files in the `my_settings/brand` folder with your files of the exact names. These files must be in .png format.