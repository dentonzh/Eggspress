---
sidebar: "index"

numberOfPostsPerPage: 8

orderPostsBy: "weight"
orderPostsByReversed: false

orderPagesBy: "alphabetical"
orderPagesByReversed: false

orderCategoriesBy: "alphabetical"
orderCategoriesByReversed: false

orderAuthorsBy: "weight"
orderAuthorsByReversed: false

showPostCardCategory: false
showPostCardDate: false
showPostCardAuthor: false
showPostCardSnippet: true
showPostCardReadMoreButton: true

colorThemeDarkPrimary: "slate-900"
colorThemeDarkSecondary: "slate-800"
colorThemeDarkFooter: "slate-900"
colorThemeLightPrimary: "gray-100"
colorThemeLightSecondary: "white"
colorThemeLightFooter: "gray-100"

colorHeroHeadlineDark: "gray-200"
colorHeroHeadlineLight: "gray-800"
colorHeroSubtitleDark: "gray-200"
colorHeroSubtitleLight: "gray-800"
colorHeroSectionStringDark: "gray-200"
colorHeroSectionStringLight: "gray-800"
colorHeroSectionLinkDark: "gray-200"
colorHeroSectionLinkLight: "gray-800"
colorHeroDateDark: "gray-200"
colorHeroDateLight: "gray-800"
---

The "sidebar" key allows you to specify which sidebar to display on the main ("index") page. By default, it points to a sidebar in the my_sidebars folder named index.md. To change this sidebar, open the my_sidebars folder and edit index.md.

Keys prefixed with "showPostCard" allow you to toggle elements that appear in post cards on and off. The title of the post must appear, but all other elements can be switched on or off. If an item is on, it should be set to "true" (without quotation marks) and "false" or empty otherwise.

Keys prefixed with "color" allow you to define the color scheme of your Eggspress blog. Eggspress uses Tailwind, which includes and expansive set of colors to select from. Color shades for these options are limited to 50, 100, 200, 800, 900, and 950. The color "white" is also available without color shades. We recommend choosing 50, 100, and 200 for light mode and 800, 900, and 950 colors for dark mode.

All color keys are split between light and dark mode with "Light" and "Dark" suffixes.

colorTheme sets the background colors for the entire site.

colorHero sets the text color for specific text elements in the hero banner.