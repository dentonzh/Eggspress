---
sidebar: "index"

numberOfPostsPerPage: 8

hiddenContentMessage: "This page is archived and may contain out of date information."
hiddenContentIsHidden: false
hiddenContentIsHiddenMessageHeading: "This content is unavailable"
hiddenContentIsHiddenMessageBodyText: "We're sorry, the page you're visiting is no longer available."


paginatedPostHeadlineSeparator: ""
paginatedCategoryHeadlineSeparator: ""
paginatedAuthorHeadlineSeparator: ""
paginatedPostSubtitlePrefix: " // Page "
paginatedCategorySubtitlePrefix: " // Page "
paginatedAuthorSubtitlePrefix: " // Page "

paginatedSubheadingIndexPrefix: "Displaying posts "
paginatedSubheadingTotalPrefix: " of "

orderPostsBy: "date"
orderPostsByReversed: false
orderPostsInCategoriesBy: "date"
orderPostsInCategoriesByReversed: false
orderPostsInAuthorsBy: "date"
orderPostsInAuthorsByReversed: false

orderPagesBy: "alphabetical"
orderPagesByReversed: false

orderCategoriesBy: "alphabetical"
orderCategoriesByReversed: false

orderAuthorsBy: "weight"
orderAuthorsByReversed: false

showPostCardCategory: true
showPostCardDate: true
showPostCardAuthor: false
showPostCardSnippet: true
showPostCardReadMoreButton: true

colorThemeDarkPrimary: "slate-900"
colorThemeDarkSecondary: "slate-800"
colorThemeDarkFooter: "slate-900"
colorThemeLightPrimary: "gray-100"
colorThemeLightSecondary: "white"
colorThemeLightFooter: "gray-100"

colorNavMenuBackgroundDark: "slate-800"
colorNavMenuBackgroundLight: "white"
colorNavMenuShadowDark: "gray-700"
colorNavMenuShadowLight: "gray-700"

colorHeroHeadlineDark: "gray-200"
colorHeroHeadlineLight: "gray-800"
colorHeroSubtitleDark: ""
colorHeroSubtitleLight: ""
colorHeroSubheadingDark: "gray-200"
colorHeroSubheadingLight: "gray-800"
colorHeroSectionStringDark: "gray-200"
colorHeroSectionStringLight: "gray-800"
colorHeroSectionLinkDark: "gray-200"
colorHeroSectionLinkLight: "gray-800"
colorHeroDateDark: "gray-200"
colorHeroDateLight: "gray-800"
---

The "sidebar" key allows you to specify which sidebar to display on the main ("index") page. By default, it points to a sidebar in the my_sidebars folder named index.md. To change this sidebar, open the my_sidebars folder and edit index.md.

Keys prefixed with "showPostCard" allow you to toggle elements that appear in post cards on and off. The title of the post must appear, but all other elements can be switched on or off. If an item is on, it should be set to "true" (without quotation marks) and "false" or empty otherwise.

Keys prefixed with "color" allow you to define the color scheme of your Eggspress blog. Eggspress uses Tailwind, which includes and expansive set of colors to select from. 

Color shades in Tailwind typically come in steps ranging from 50 to 950. To improve performance, Eggspress limits the number of shades to 50, 100, 200, 300, 700, 800, 900, and 950 (omitting 400, 500, and 600). The color "white" is also available without color shades. We recommend choosing 50, 100, and 200 for light mode and 800, 900, and 950 colors for dark mode.

All color keys are split between light and dark mode with "Light" and "Dark" suffixes.

colorTheme sets the background colors for the entire site.

colorHero sets the text color for specific text elements in the hero banner.

To change your icons and logos, replace the files in the `my_settings/brand` folder with your files of the exact names. These files must be in .png format.