---
linkTwitter: "https://twitter.com/EggspressBlog"
linkFacebook: "https://facebook.com/EggspressBlog"
linkInstagram: "https://www.instagram.com/eggspressblog/"
linkLinkedin: "https://www.linkedin.com/company/eggspress"
linkGithub: "https://github.com/dentonzh/Eggspress"
linkToWebsite1: "https://opencourser.com"
nameForWebsite1: "OpenCourser"
linkToWebsite2: ""
nameForWebsite2: ""
linkToWebsite3: ""
nameForWebsite3: ""
---