---
pinnedPost1: "welcome-to-eggspress"
pinnedPost2: ""
pinnedPost3: ""

heading1: "This is a new Eggspress site!"
image1: ""
text1: "You can customize this sidebar by editing index.md in your \"my_sidebars\" folder"
linkText1: ""
link1: ""

heading2: "You can add images to sidebars"
image2: "eggspress_zen.jpeg"
text2: "Eggspress is a temple for your thoughts"
linkText2: ""
link2: ""

heading3: "If you need help..."
image3: ""
text3: "Create an issue on the main Eggspress repository"
linkText3: "Create Issue"
link3: "https://github.com/dentonzh/Eggspress/issues/new"

heading4: "Follow Eggspress on Twitter"
image4: ""
text4: ""
linkText4: "@EggspressBlog"
link4: "https://twitter.com/eggspressblog"

heading5: ""
image5: ""
text5: ""
linkText5: ""
link5: ""

heading6: ""
image6: ""
text6: ""
linkText6: ""
link6: ""

heading7: ""
image7: ""
text7: ""
linkText7: ""
link7: ""

heading8: ""
image8: ""
text8: ""
linkText8: ""
link8: ""

heading9: ""
image9: ""
text9: ""
linkText9: ""
link9: ""
---
