---
title: "About Eggspress"
tagline: "What can your Eggspress site do for you?"
sidebar: "about"
weight: 1
---

I built Eggspress as an easy way for anyone to deploy a fast, lightweight, blog for free.
It started as a side project to remake my own personal blog, but has since grown to become my first
open source project.

## Why Eggspress

There are a lot of blogging platforms, starters, and templates out there. Many of them come chock full of features and customization settings that go far beyond where Eggspress will ever go. But if you need something that's really fast and has all of the core features that most bloggers need, then Eggspress is a pretty good place to start.

Eggspress exists because it's designed from the very start to help anyone[^1] launch a blog using modern technologies. Every design decision revolves around maximizing choice and flexibility, including the freedom to deploy wherever you please[^2].

## Blogging on your terms

You'll never have to worry about getting stuck on one platform or service when you're using Eggspress. As your site grows and your needs expand, you can migrate Eggspress to a more robust server or leave Eggspress altogether. Just move your Markdown files![^3]

Find my Eggspress-powered blog at [dentonzhou.com](https://dentonzhou.com) and get in touch by emailing me at eggspressblog (at) gmail. If you need any help, feel free to open a [new issue](https://github.com/dentonzh/Eggspress/issues/new) on the Eggspress repository over at Github.

All the best and happy blogging,


Denton

[^1]: Well, almost anyone. Setting up requires some computer skills. Minimally, you need to know how to organize files and folders on your computer, how to drag-and-drop multiple folders into a browser window, and install a Markdown editor like Obsidian. But you'll never need to write a line of code or touch the command line.
[^2]: Currently, the documentation helps you launch on Vercel, but it's possible to read other guides and tutorials and launch on other platforms without that much more work.
[^3]: A nice secondary benefit to this is that if you ever break something in Eggspress, you can delete your forked repository, create a new fork, and drop your workspace files onto the new fork. It'll be as if nothing ever happened!