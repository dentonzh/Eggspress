---
name: "Eggie Shellvetica"
postnomials: ""
description: "Nestled in a cozy shell adorned with typewriter keys, Eggie brings joy to the world of blogging with each click of a key! 🐣📝✨"
isVisible: true

image: eggie_profile.png
role: "Editor-in-Chief"
weight: 5
orderPostsBy: "date"
orderPostsByReversed: false
location: "New York, NY"
education: ""
degree: ""
work: ""
company: ""
title: ""
specialty: ""
team: ""
pronouns: ""

socialPlatform1: "Twitter"
socialLink1: "https://twitter.com/EggspressBlog"
socialHandle1: "@EggspressBlog"

socialPlatform2: ""
socialLink2: ""
socialHandle2: ""

socialPlatform3: ""
socialLink3: ""
socialHandle3: ""

socialPlatform4: ""
socialLink4: ""
socialHandle4: ""

socialPlatform5: ""
socialLink5: ""
socialHandle5: ""

socialPlatform6: ""
socialLink6: ""
socialHandle6: ""

socialPlatform7: ""
socialLink7: ""
socialHandle7: ""

socialPlatform8: ""
socialLink8: ""
socialHandle8: ""

socialPlatform9: ""
socialLink9: ""
socialHandle9: ""

websiteLabel1: "My website"
websiteLink1: "https://opencourser.com"
websiteName1: "OpenCourser"
websiteDescription1: "This is where I learned how to code!"


websiteLabel2: ""
websiteLink2: ""
websiteName2: ""
websiteDescription2: ""

websiteLabel3: ""
websiteLink3: ""
websiteName3: ""
websiteDescription3: ""

websiteLabel4: ""
websiteLink4: ""
websiteName4: ""
websiteDescription4: ""

websiteLabel5: ""
websiteLink5: ""
websiteName5: ""
websiteDescription5: ""

websiteLabel6: ""
websiteLink6: ""
websiteName6: ""
websiteDescription6: ""

websiteLabel7: ""
websiteLink7: ""
websiteName7: ""
websiteDescription7: ""

websiteLabel8: ""
websiteLink8: ""
websiteName8: ""
websiteDescription8: ""

websiteLabel9: ""
websiteLink9: ""
websiteName9: ""
websiteDescription9: ""
---

