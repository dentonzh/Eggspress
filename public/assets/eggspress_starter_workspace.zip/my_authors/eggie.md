---
name: "Eggie Shellvetica"
postnomials: ""
description: "Nestled in a cozy shell adorned with typewriter keys, Eggie brings joy to the world of blogging with each click of a key! 🐣📝✨"
image: eggie_profile.png
role: "Editor-in-Chief"
weight: "5"
orderPostsBy: "date"
orderPostsByReversed: false
location: "New York, NY"
education: ""
degree: ""
work: ""
company: ""
title: ""
specialty: ""
team: ""
pronouns: ""
socialPlatform1: "Twitter"
socialLink1: "https://twitter.com/EggspressBlog"
socialHandle1: "@EggspressBlog"
socialPlatform2: ""
socialLink2: ""
socialHandle2: ""
websiteName: "OpenCourser is where I learned how to code!"
websiteLink: "https://opencourser.com"
---

