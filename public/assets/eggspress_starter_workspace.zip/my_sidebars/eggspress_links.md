---
isVisible: true

pinnedPost1: ""
pinnedPost2: ""
pinnedPost3: ""
pinnedPost4: ""
pinnedPost5: ""
pinnedPost6: ""
pinnedPost7: ""
pinnedPost8: ""
pinnedPost9: ""

heading1: "For developers"
image1: ""
text1: "Get started right away by forking the Eggspress repository."
linkText1: "Fork on Github"
link1: "https://github.com/dentonzh/Eggspress"

heading2: "For everyone else"
image2: ""
text2: "Use our detailed guides to deploy and publish in under an hour. No command line or code needed."
linkText2: "See: Getting Started"
link2: "/"


heading3: "Follow us"
image3: ""
text3: ""
linkText3: "@EggspressBlog"
link3: "https://twitter.com/eggspressblog"

heading4: ""
image4: ""
text4: ""
linkText4: ""
link4: ""

heading5: ""
image5: ""
text5: ""
linkText5: ""
link5: ""

heading6: ""
image6: ""
text6: ""
linkText6: ""
link6: ""

heading7: ""
image7: ""
text7: ""
linkText7: ""
link7: ""

heading8: ""
image8: ""
text8: ""
linkText8: ""
link8: ""

heading9: ""
image9: ""
text9: ""
linkText9: ""
link9: ""
---