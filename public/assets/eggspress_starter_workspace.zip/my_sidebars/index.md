---
pinnedPost1: "first-post"
pinnedPost2: "second-post"
pinnedPost3: ""

heading1: "Welcome to my blog!"
image1: ""
text1: "I'm Eggspress's beloved ambassador of creativity. My world revolves around bringing joy to the blogosphere through whimsical tales and creative adventures!"
linkText1: ""
link1: ""

heading2: "Where I work"
image2: "eggspress_office.jpeg"
text2: "Eggspress!"
linkText2: ""
link2: ""

heading3: "My hobbies"
image3: ""
text3: "Nest decor, sunshine lounging"
linkText3: ""
link3: ""

heading4: "Follow me on Twitter"
image4: ""
text4: ""
linkText4: "@EggspressBlog"
link4: "https://twitter.com/eggspressblog"

heading5: ""
image5: ""
text5: ""
linkText5: ""
link5: ""

heading6: ""
image6: ""
text6: ""
linkText6: ""
link6: ""

heading7: ""
image7: ""
text7: ""
linkText7: ""
link7: ""

heading8: ""
image8: ""
text8: ""
linkText8: ""
link8: ""

heading9: ""
image9: ""
text9: ""
linkText9: ""
link9: ""
---
